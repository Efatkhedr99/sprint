1- What ’re the methods that you used ?




2- Explain each method ..



3- What’s new for you ?



4- Resources ? 
